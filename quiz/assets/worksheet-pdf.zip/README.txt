SkillrHub PDF fix v12

1. Upload worksheet-pdf.js EXACTLY as:
   /quiz/assets/worksheet-pdf.js

2. In every quiz index page, keep ONLY ONE worksheet PDF script line:
   <script src="/quiz/assets/worksheet-pdf.js?v=12"></script>

3. Delete any other worksheet PDF script lines such as:
   worksheet-pdf-v10.js
   worksheet-pdf-v11.js
   older worksheet-pdf.js?v=...

4. Hard refresh the page.

Quick browser-console check:
   window.skillrWorksheetPdfVersion
It MUST return:
   "12"

The download button is cloned by v12 so old cached PDF click handlers are removed.
This generator draws directly with jsPDF; it does NOT screenshot HTML.

"use strict";

const fs = require("fs");
const vm = require("vm");

const CODES = [
  "ac9m1a01", "ac9m1a02", "ac9m1m01", "ac9m1m02", "ac9m1m03",
  "ac9m1sp01", "ac9m1sp02", "ac9m1st01", "ac9m1st02"
];
const ALL_CODES = [
  "ac9m1n01", "ac9m1n02", "ac9m1n03", "ac9m1n04", "ac9m1n05", "ac9m1n06",
  ...CODES
];
const EXPECTED = { practice:28, test:12, quiz:50 };

function load(file, seed={}) {
  const context = { window:seed, console };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(file,"utf8"),context,{filename:file});
  return context.window;
}
function scene(q) { return `${q.question}\n${q.visual || q.imageAlt || ""}`; }
function assert(condition,message) { if (!condition) throw new Error(message); }

const report = JSON.parse(fs.readFileSync("year1-maths-remaining-rebuild-report.json","utf8"));
assert(Object.keys(report.codes || {}).length === 9,"Report must contain nine remaining codes");
assert(report.totals.practice === 252,`Expected 252 Practice questions, found ${report.totals.practice}`);
assert(report.totals.test === 108,`Expected 108 Test questions, found ${report.totals.test}`);
assert(report.totals.quiz === 450,`Expected 450 Quiz questions, found ${report.totals.quiz}`);
assert(report.totals.questions === 810,`Expected 810 total questions, found ${report.totals.questions}`);
assert(report.dailyDrills.total >= 90,`Expected at least 90 Daily Drill additions, found ${report.dailyDrills.total}`);

for (const code of CODES) {
  const banks = {};
  const allScenes = new Set();
  for (const bank of ["practice","test","quiz"]) {
    const file = bank === "practice"
      ? `quiz/year-1/math/${code}/practice/questions.js`
      : bank === "test"
        ? `quiz/year-1/math/${code}/test/questions.js`
        : `quiz/year-1/math/${code}/questions.js`;
    const win = load(file);
    const questions = win.quizQuestions;
    assert(Array.isArray(questions),`${file}: question array not loaded`);
    assert(questions.length === EXPECTED[bank],`${file}: expected ${EXPECTED[bank]}, found ${questions.length}`);
    if (bank === "practice") assert(win.skillrPracticeQuestions === questions,`${file}: Practice handoff failed`);
    if (bank === "test") assert(win.skillrTestQuestions === questions && win.skillrExamQuestions === questions,`${file}: Test handoff failed`);
    if (bank === "quiz") assert(win.skillrQuizQuestions === questions,`${file}: Quiz handoff failed`);
    assert(new Set(questions.map(q=>q.id)).size === questions.length,`${file}: duplicate IDs`);
    assert(new Set(questions.map(scene)).size === questions.length,`${file}: duplicate scenes`);
    const skills = new Set(questions.map(q=>String(q.skill || "").toLowerCase()));
    const minimumSkills = bank === "practice" ? 12 : bank === "test" ? 8 : 15;
    assert(skills.size >= minimumSkills,`${file}: only ${skills.size} skill purposes; expected at least ${minimumSkills}`);
    let visuals = 0;
    for (const q of questions) {
      const text = `${q.question || ""} ${q.explanation || ""} ${JSON.stringify(q.answers || [])}`;
      assert(q.question && q.explanation && q.skill,`${q.id}: incomplete item`);
      assert(!["self-check","text","fill-blank","drag-drop","drag-image"].includes(q.type),`${q.id}: subjective/unsupported type ${q.type}`);
      assert(!/which answer fits|number sense problem|question \d+:|a different answer|not enough information|answers may vary|which learning goal best|which classroom activity best|self-check/i.test(text),`${q.id}: generic or banned prompt`);
      assert(!/\b1 (ones|tens|hundreds)\b|\b(1th|2th|3th|21th|22th|23th|31th)\b|\ba ice-cream\b/i.test(text),`${q.id}: grammar regression`);
      const sig = scene(q);
      assert(!allScenes.has(sig),`${code}: cross-bank scene overlap`);
      allScenes.add(sig);
      if (q.image) {
        visuals += 1;
        assert(q.image.startsWith("data:image/svg+xml"),`${q.id}: visual is not SVG`);
        const decoded = decodeURIComponent(q.image.split(",").slice(1).join(","));
        assert(/width="13cm"/.test(decoded) && /height="5cm"/.test(decoded),`${q.id}: SVG dimensions are not explicit`);
        assert(/role="img"/.test(decoded) && /<desc/.test(decoded),`${q.id}: SVG accessibility text missing`);
        assert(String(q.imageAlt || "").trim(),`${q.id}: imageAlt missing`);
      }
      if (["single","true-false"].includes(q.type)) {
        assert(Array.isArray(q.answers) && q.answers.length >= 2,`${q.id}: too few answers`);
        assert(new Set(q.answers.map(String)).size === q.answers.length,`${q.id}: duplicate answer choices`);
        assert(Number.isInteger(q.correct) && q.correct >= 0 && q.correct < q.answers.length,`${q.id}: invalid correct index`);
      } else if (q.type === "multiple") {
        assert(Array.isArray(q.answers) && q.answers.length >= 3,`${q.id}: invalid multiple answers`);
        assert(new Set(q.answers.map(String)).size === q.answers.length,`${q.id}: duplicate multiple choices`);
        assert(Array.isArray(q.correct) && q.correct.length >= 2 && q.correct.length < q.answers.length,`${q.id}: invalid multiple correct set`);
        assert(q.correct.every(i=>Number.isInteger(i) && i>=0 && i<q.answers.length),`${q.id}: invalid multiple index`);
      } else if (q.type === "number") {
        assert(typeof q.correct === "number" && Number.isFinite(q.correct),`${q.id}: invalid number answer`);
      } else if (q.type === "order") {
        assert(Array.isArray(q.items) && Array.isArray(q.correct) && q.items.length === q.correct.length && q.items.length >= 3,`${q.id}: invalid order item`);
        assert(new Set(q.items.map(String)).size === q.items.length,`${q.id}: duplicate order cards`);
      } else {
        throw new Error(`${q.id}: unsupported type ${q.type}`);
      }
    }
    banks[bank] = questions;
    const minimumVisuals = bank === "test" ? 3 : bank === "practice" ? 8 : 10;
    assert(visuals >= minimumVisuals,`${file}: only ${visuals} SVG-supported items; expected at least ${minimumVisuals}`);
  }

  const practicePage = fs.readFileSync(`quiz/year-1/math/${code}/practice/index.html`,"utf8");
  const testPage = fs.readFileSync(`quiz/year-1/math/${code}/test/index.html`,"utf8");
  const quizPage = fs.readFileSync(`quiz/year-1/math/${code}/quiz/index.html`,"utf8");
  assert(practicePage.includes('"maxQuestions":8') && practicePage.includes('"questionCycle":true') && practicePage.includes('"shuffleQuestions":true'),`${code}: Practice rotation config missing`);
  assert(testPage.includes('"maxQuestions":12') && testPage.includes('"questionCycle":false') && testPage.includes('"shuffleQuestions":false'),`${code}: Test config missing`);
  assert(quizPage.includes('"maxQuestions":10') && quizPage.includes('"questionCycle":true') && quizPage.includes('"shuffleQuestions":true'),`${code}: Quiz rotation config missing`);
  assert(practicePage.includes("20260813-y1-complete") && testPage.includes("20260813-y1-complete") && quizPage.includes("20260813-y1-complete"),`${code}: current cache token missing`);
  const activity = fs.readFileSync(`quiz/year-1/math/${code}/index.html`,"utf8");
  assert(activity.includes(`/quiz/year-1/math/${code}/quiz/`),`${code}: activity Quiz link missing`);
}

const extensionFile = "quiz/assets/daily-drills/year1-maths-remaining-extensions.js";
const extensionWindow = load(extensionFile,{});
const extensions = extensionWindow.SkillrDailyQuestionExtensions?.["1"]?.math || {};
let extensionTotal = 0;
const perCode = Object.fromEntries(CODES.map(code=>[code.toUpperCase(),0]));
for (const [skill,questions] of Object.entries(extensions)) {
  assert(Array.isArray(questions),`${skill}: Daily Drill extension is not an array`);
  extensionTotal += questions.length;
  for (const q of questions) {
    assert(q.curriculumCode in perCode,`${q.id}: unexpected curriculum code ${q.curriculumCode}`);
    perCode[q.curriculumCode] += 1;
    assert(!["self-check","text"].includes(q.type),`${q.id}: subjective Daily Drill item`);
  }
  const page = fs.readFileSync(`quiz/year-1/daily-drills/math/${skill}/index.html`,"utf8");
  assert(page.includes("year1-maths-remaining-extensions.js"),`${skill}: Daily Drill page does not load remaining extension`);
}
assert(extensionTotal === report.dailyDrills.total,`Daily Drill report mismatch: ${extensionTotal} vs ${report.dailyDrills.total}`);
for (const [code,count] of Object.entries(perCode)) assert(count === 12,`${code}: expected 12 Daily Drill items, found ${count}`);

const qa = fs.readFileSync("assets/qa-complete-ribbon.js","utf8");
for (const code of ALL_CODES) assert(qa.includes(`"${code}"`),`QA ribbon missing ${code}`);
assert(qa.includes('"/year1/curriculum/maths"'),"Year 1 Maths subject-level QA path missing");
assert(qa.includes("applyYear1SubjectBadge"),"Year 1 subject tile QA badge missing");

const css = fs.readFileSync("quiz/assets/style.css","utf8");
assert(/\.question-image[\s\S]*min-width:\s*1\.3cm/.test(css),"Question image minimum width is missing");
assert(/\.question-image[\s\S]*min-height:\s*1\.3cm/.test(css),"Question image minimum height is missing");

const sw = fs.readFileSync("service-worker.js","utf8");
assert(sw.includes("year1-maths-remaining-extensions.js"),"Service worker does not network-first the new Daily Drill extension");
assert(sw.includes("/assets/qa-complete-ribbon.js"),"Service worker does not network-first the QA ribbon");
assert(!fs.existsSync("quiz/assets/daily-drills/year1-maths-rebuild-extensions.js"),"Obsolete full-rebuild extension was not removed");

console.log(JSON.stringify({
  status:"passed",
  codes:CODES.length,
  questions:report.totals.questions,
  visuals:report.totals.visuals,
  dailyDrills:extensionTotal,
  qa:"Content QA complete; human QA pending."
},null,2));

"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = process.cwd();
const CODES = [
  "ac9m1a01", "ac9m1a02", "ac9m1m01", "ac9m1m02", "ac9m1m03",
  "ac9m1sp01", "ac9m1sp02", "ac9m1st01", "ac9m1st02"
];

const TITLES = {
  ac9m1a01: "Skip-counting Pattern Sequences",
  ac9m1a02: "Repeating Patterns",
  ac9m1m01: "Comparing Length, Mass, Capacity and Duration",
  ac9m1m02: "Measuring Length with Informal Units",
  ac9m1m03: "Time: Years, Months, Weeks, Days and Hours",
  ac9m1sp01: "Familiar Shapes and Objects",
  ac9m1sp02: "Directions and Location",
  ac9m1st01: "Collecting Categorical Data",
  ac9m1st02: "Representing and Comparing Data"
};

function full(rel) { return path.join(ROOT, rel); }
function read(rel) { return fs.readFileSync(full(rel), "utf8"); }
function write(rel, content) {
  fs.mkdirSync(path.dirname(full(rel)), { recursive: true });
  fs.writeFileSync(full(rel), content, "utf8");
}
function load(rel) {
  const window = {};
  const context = { window, console };
  vm.createContext(context);
  vm.runInContext(read(rel), context, { filename: rel });
  return window.quizQuestions || window.skillrPracticeQuestions || window.skillrTestQuestions || window.skillrQuizQuestions || [];
}
function save(code, bank, questions) {
  let content = '"use strict";\n';
  if (bank === "practice") content += `window.skillrPracticeQuestions = ${JSON.stringify(questions, null, 2)};\nwindow.quizQuestions = window.skillrPracticeQuestions;\n`;
  if (bank === "test") content += `window.skillrTestQuestions = ${JSON.stringify(questions, null, 2)};\nwindow.skillrExamQuestions = window.skillrTestQuestions;\nwindow.quizQuestions = window.skillrTestQuestions;\n`;
  if (bank === "quiz") content += `window.skillrQuizQuestions = ${JSON.stringify(questions, null, 2)};\nwindow.quizQuestions = window.skillrQuizQuestions;\n`;
  const rel = bank === "practice"
    ? `quiz/year-1/math/${code}/practice/questions.js`
    : bank === "test"
      ? `quiz/year-1/math/${code}/test/questions.js`
      : `quiz/year-1/math/${code}/questions.js`;
  write(rel, content);
  if (bank === "practice") write(`quiz/year-1/math/${code}/practice/practice-questions.js`, content);
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&apos;" }[char]));
}
function clean(value) { return String(value ?? "").replace(/\s+/g, " ").trim(); }
function short(value, max = 100) {
  const text = clean(value);
  return text.length <= max ? text : `${text.slice(0, max - 1).replace(/\s+\S*$/, "")}…`;
}
function dataSvg(title, desc, body) {
  const source = `<svg xmlns="http://www.w3.org/2000/svg" width="13cm" height="5cm" viewBox="0 0 640 246" role="img" aria-labelledby="title desc"><title id="title">${esc(title)}</title><desc id="desc">${esc(desc)}</desc><style>
.bg{fill:#f8fbff}.panel{fill:#fff;stroke:#9dbcf6;stroke-width:2}.line{stroke:#173968;stroke-width:5;stroke-linecap:round;fill:none}.thin{stroke:#7890ad;stroke-width:2;fill:none}.arrow{stroke:#2457d6;stroke-width:5;stroke-linecap:round;stroke-linejoin:round;fill:none;marker-end:url(#arrow)}.blue{fill:#4dabf7;stroke:#173968;stroke-width:2}.green{fill:#69db7c;stroke:#17643a;stroke-width:2}.yellow{fill:#ffd43b;stroke:#a35d00;stroke-width:2}.red{fill:#ff8787;stroke:#a61e4d;stroke-width:2}.purple{fill:#b197fc;stroke:#5f3dc4;stroke-width:2}.white{fill:#fff;stroke:#7890ad;stroke-width:2}.label{font:800 17px Arial,Helvetica,sans-serif;fill:#173968}.small{font:700 14px Arial,Helvetica,sans-serif;fill:#203047}.tiny{font:700 11px Arial,Helvetica,sans-serif;fill:#40536d}.caption{font:700 13px Arial,Helvetica,sans-serif;fill:#40536d}.tally{stroke:#2457d6;stroke-width:5;stroke-linecap:round}.grid{fill:#fff;stroke:#9dbcf6;stroke-width:1.5}</style><defs><marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto"><path d="M0 0 L10 5 L0 10 Z" fill="#2457d6"/></marker></defs><rect width="640" height="246" rx="18" class="bg"/>${body}<rect x="20" y="207" width="600" height="27" rx="8" class="panel"/><text x="320" y="226" class="caption" text-anchor="middle">${esc(short(desc, 88))}</text></svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(source)}`;
}
function dots(x, y, count, colour = "blue", columns = 5, gap = 18) {
  return Array.from({ length: count }, (_, index) => `<circle cx="${x + (index % columns) * gap}" cy="${y + Math.floor(index / columns) * gap}" r="6" class="${colour}"/>`).join("");
}
function numbersFrom(value) { return (String(value).match(/\b\d+\b/g) || []).map(Number); }
function detectStep(text) {
  const match = text.match(/(?:by|add(?:ing)?|\+)\s*-?\s*(2|5|10)s?\b/i);
  if (match) return Number(match[1]);
  return /twos/i.test(text) ? 2 : /fives/i.test(text) ? 5 : /tens/i.test(text) ? 10 : 2;
}

function a01Visual(question) {
  const text = clean(`${question.skill} ${question.question} ${question.imageAlt || ""}`);
  const step = detectStep(text);
  if (/object|equal group|bracket|collection|group display/i.test(text)) {
    const groupCount = 4;
    const w = step === 10 ? 105 : step === 5 ? 83 : 70;
    const start = 45;
    const gap = 18;
    const body = Array.from({ length: groupCount }, (_, group) => {
      const x = start + group * (w + gap);
      return `<rect x="${x}" y="70" width="${w}" height="105" rx="14" class="panel"/>${dots(x + 17, 92, step, ["blue","green","yellow","red"][group], Math.min(5, step), 15)}<text x="${x + w/2}" y="164" class="small" text-anchor="middle">group of ${step}</text>`;
    }).join("");
    return { image: dataSvg(TITLES.ac9m1a01, `Four equal groups with ${step} objects in each group show counting by ${step}s.`, body), alt: `Four equal groups with ${step} objects in each group show counting by ${step}s.` };
  }
  const values = numbersFrom(question.question).slice(0, 7);
  const labels = values.length >= 2 ? values : Array.from({ length: 6 }, (_, i) => i * step);
  const x0 = 62, x1 = 578, y = 120;
  const body = `<line x1="${x0}" y1="${y}" x2="${x1}" y2="${y}" class="line"/>${labels.map((value,index) => {
    const x = x0 + index * ((x1-x0)/Math.max(1,labels.length-1));
    return `<circle cx="${x}" cy="${y}" r="19" class="${["blue","green","yellow"][index%3]}"/><text x="${x}" y="126" class="small" text-anchor="middle">${value}</text>${index<labels.length-1?`<path d="M${x+23} 82 Q${x+48} 49 ${x+75} 82" class="arrow"/>`:""}`;
  }).join("")}<text x="320" y="177" class="label" text-anchor="middle">equal jumps of ${step}</text>`;
  return { image: dataSvg(TITLES.ac9m1a01, `A number sequence shown with equal jumps of ${step}.`, body), alt: `A number sequence shown with equal jumps of ${step}.` };
}

function a02Visual(question) {
  const text = clean(`${question.question} ${question.imageAlt || ""}`).toLowerCase();
  const unit = /yellow triangle.*yellow triangle.*green circle/.test(text)
    ? ["yellow-triangle","yellow-triangle","green-circle"]
    : /blue square.*red circle.*red circle/.test(text)
      ? ["blue-square","red-circle","red-circle"]
      : ["red-circle","blue-square"];
  const sequence = [...unit, ...unit, ...unit.slice(0,2)];
  const body = sequence.map((item,index) => {
    const x = 60 + index * 68;
    if (item.includes("circle")) return `<circle cx="${x}" cy="112" r="25" class="${item.startsWith("red")?"red":"green"}"/>`;
    return `<rect x="${x-25}" y="87" width="50" height="50" rx="8" class="${item.startsWith("blue")?"blue":"yellow"}"/>`;
  }).join("") + `<path d="M48 164 H${48 + unit.length*68}" class="line"/><text x="${48 + unit.length*34}" y="188" class="small" text-anchor="middle">smallest repeating unit</text>`;
  return { image: dataSvg(TITLES.ac9m1a02, "A colourful pattern repeats the same smallest unit again and again.", body), alt: "A colourful pattern repeats the same smallest unit again and again." };
}

function balanceVisual(text) {
  const level = /stays level|level balance|equal mass|masses are equal/i.test(text);
  const fullBottle = /full bottle/i.test(text);
  const leftLabel = fullBottle ? "full bottle" : /toy a/i.test(text) ? "toy A" : "object A";
  const rightLabel = /empty cup/i.test(text) ? "empty cup" : /toy b/i.test(text) ? "toy B" : "object B";
  const leftY = level ? 102 : 125;
  const rightY = level ? 102 : 79;
  const leftObject = fullBottle
    ? `<path d="M187 ${leftY+10} H223 V${leftY+20} C235 ${leftY+27} 237 ${leftY+42} 234 ${leftY+61} H176 C173 ${leftY+42} 175 ${leftY+27} 187 ${leftY+20} Z" class="blue"/><rect x="192" y="${leftY+4}" width="26" height="10" rx="3" class="blue"/>`
    : `<rect x="177" y="${leftY+23}" width="56" height="39" rx="8" class="red"/><circle cx="190" cy="${leftY+67}" r="8" class="purple"/><circle cx="220" cy="${leftY+67}" r="8" class="purple"/>`;
  const rightObject = /empty cup/i.test(text)
    ? `<path d="M407 ${rightY+24} H452 L445 ${rightY+61} H414 Z" class="green"/><path d="M452 ${rightY+31} Q474 ${rightY+34} 458 ${rightY+52}" class="line"/>`
    : `<circle cx="435" cy="${rightY+44}" r="25" class="purple"/>`;
  const body = `<polygon points="320,64 286,190 354,190" class="yellow"/><line x1="170" y1="${leftY}" x2="470" y2="${rightY}" class="line"/><line x1="205" y1="${leftY+2}" x2="205" y2="${leftY+48}" class="thin"/><line x1="435" y1="${rightY+2}" x2="435" y2="${rightY+48}" class="thin"/><path d="M155 ${leftY+48} H255 L238 ${leftY+75} H172 Z" class="blue"/><path d="M385 ${rightY+48} H485 L468 ${rightY+75} H402 Z" class="green"/>${leftObject}${rightObject}<text x="205" y="${Math.min(202,leftY+100)}" class="small" text-anchor="middle">${esc(leftLabel)}</text><text x="435" y="${Math.min(202,rightY+100)}" class="small" text-anchor="middle">${esc(rightLabel)}</text>`;
  const desc = level ? `A level balance shows ${leftLabel} and ${rightLabel} have equal mass.` : `A balance tilts down on the ${leftLabel} side, showing it is heavier than ${rightLabel}.`;
  return { body, desc };
}
function capacityVisual() {
  const body = `<path d="M110 64 H255 L238 178 H127 Z" class="blue"/><path d="M133 116 H232 L222 169 H141 Z" class="green"/><path d="M375 96 H500 L485 178 H390 Z" class="purple"/><path d="M397 136 H478 L470 169 H405 Z" class="yellow"/><text x="182" y="198" class="small" text-anchor="middle">large jug</text><text x="438" y="198" class="small" text-anchor="middle">small cup</text><path d="M270 120 H355" class="arrow"/>`;
  return { body, desc: "A large jug and a small cup are compared by how much each container can hold." };
}
function lengthVisual(text) {
  const bLonger = /line b.*longer|b:.*—{6,}/i.test(text) || !/line a.*longer/i.test(text);
  const lenA = bLonger ? 230 : 380, lenB = bLonger ? 380 : 230;
  const body = `<line x1="100" y1="86" x2="${100+lenA}" y2="86" class="line"/><text x="72" y="92" class="label">A</text><line x1="100" y1="150" x2="${100+lenB}" y2="150" class="line"/><text x="72" y="156" class="label">B</text><line x1="100" y1="62" x2="100" y2="174" class="thin"/><text x="320" y="193" class="small" text-anchor="middle">same starting point</text>`;
  return { body, desc: "Two lines start at the same point so their lengths can be compared fairly." };
}
function durationVisual() {
  const body = `<circle cx="155" cy="115" r="52" class="white"/><line x1="155" y1="115" x2="155" y2="78" class="line"/><line x1="155" y1="115" x2="190" y2="115" class="line"/><circle cx="475" cy="115" r="52" class="white"/><line x1="475" y1="115" x2="475" y2="73" class="line"/><line x1="475" y1="115" x2="505" y2="145" class="line"/><path d="M225 115 H405" class="arrow"/><text x="315" y="155" class="small" text-anchor="middle">compare elapsed time</text>`;
  return { body, desc: "Two clock times and a timeline show how long an event lasts." };
}
function m01Visual(question) {
  const text = clean(`${question.skill} ${question.question} ${question.imageAlt || ""}`);
  if (/balance|mass|heavier|lighter|weigh/i.test(text)) {
    const v = balanceVisual(text);
    return { image:dataSvg(TITLES.ac9m1m01,v.desc,v.body), alt:v.desc };
  }
  if (/capacity|holds more|holds less|container|jug|cup|bottle/i.test(text)) {
    const v = capacityVisual(); return { image:dataSvg(TITLES.ac9m1m01,v.desc,v.body), alt:v.desc };
  }
  if (/duration|takes longer|takes less time|event|hour|minute|song|clap/i.test(text)) {
    const v = durationVisual(); return { image:dataSvg(TITLES.ac9m1m01,v.desc,v.body), alt:v.desc };
  }
  const v = lengthVisual(text); return { image:dataSvg(TITLES.ac9m1m01,v.desc,v.body), alt:v.desc };
}

function m02Visual(question) {
  const text = clean(`${question.skill} ${question.question} ${question.imageAlt || ""}`);
  const count = Math.min(10, Math.max(4, numbersFrom(question.question)[0] || 7));
  const hasGaps = /gap/i.test(text);
  const overlaps = /overlap/i.test(text);
  const different = /different-sized|different sizes|same size|uniform/i.test(text) && /why|incorrect|unfair/i.test(text);
  let units = "";
  let x = 72;
  for (let i=0;i<count;i++) {
    const width = different ? (i%2 ? 44 : 62) : 52;
    units += `<rect x="${x}" y="112" width="${width}" height="46" rx="7" class="${["blue","green","yellow"][i%3]}"/>`;
    if (overlaps) x += width - 15;
    else if (hasGaps) x += width + 13;
    else x += width;
  }
  const issue = overlaps ? "overlapping units give an incorrect measure" : hasGaps ? "gaps give an incorrect measure" : different ? "units of different lengths do not represent equal measures" : "equal units touch end-to-end with no gaps or overlaps";
  const body = `<line x1="65" y1="77" x2="575" y2="77" class="line"/>${units}<text x="320" y="190" class="small" text-anchor="middle">${esc(issue)}</text>`;
  return { image:dataSvg(TITLES.ac9m1m02,issue,body), alt:issue[0].toUpperCase()+issue.slice(1)+"." };
}

function m03Visual(question) {
  const text = clean(`${question.skill} ${question.question} ${question.imageAlt || ""}`);
  if (/month|year/i.test(text)) {
    const months=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const body=months.map((m,i)=>`<rect x="${45+(i%6)*92}" y="${61+Math.floor(i/6)*65}" width="78" height="48" rx="8" class="${["blue","green","yellow"][i%3]}"/><text x="${84+(i%6)*92}" y="${91+Math.floor(i/6)*65}" class="small" text-anchor="middle">${m}</text>`).join("");
    const desc="The 12 months are shown in their order through one year.";
    return {image:dataSvg(TITLES.ac9m1m03,desc,body),alt:desc};
  }
  if (/hour|breakfast|lunch|sleep|wake|duration|clock/i.test(text)) {
    const v=durationVisual(); return {image:dataSvg(TITLES.ac9m1m03,v.desc,v.body),alt:v.desc};
  }
  const days=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
  const body=days.map((d,i)=>`<rect x="${59+i*75}" y="82" width="62" height="64" rx="8" class="${["blue","green","yellow"][i%3]}"/><text x="${90+i*75}" y="119" class="small" text-anchor="middle">${d}</text>`).join("")+`<path d="M85 174 H555" class="arrow"/>`;
  const desc="The seven days are shown in their weekly order.";
  return {image:dataSvg(TITLES.ac9m1m03,desc,body),alt:desc};
}

function sp01Visual(question) {
  const text=clean(`${question.skill} ${question.question} ${question.imageAlt||""}`);
  if (/cylinder|sphere|cube|cone|can|ball|box/i.test(text)) {
    const body=`<ellipse cx="105" cy="78" rx="42" ry="16" class="blue"/><rect x="63" y="78" width="84" height="84" class="blue"/><ellipse cx="105" cy="162" rx="42" ry="16" class="blue"/><circle cx="255" cy="120" r="48" class="green"/><path d="M375 78 L430 98 L430 158 L375 177 L320 158 L320 98 Z" class="yellow"/><path d="M375 78 V138 M320 98 L375 118 L430 98 M375 118 V177" class="thin"/><ellipse cx="535" cy="163" rx="48" ry="13" class="red"/><path d="M487 163 L535 68 L583 163 Z" class="red"/><text x="105" y="198" class="small" text-anchor="middle">cylinder</text><text x="255" y="198" class="small" text-anchor="middle">sphere</text><text x="375" y="198" class="small" text-anchor="middle">cube</text><text x="535" y="198" class="small" text-anchor="middle">cone</text>`;
    const desc="A cylinder, sphere, cube and cone are shown with their different faces and curved surfaces.";
    return {image:dataSvg(TITLES.ac9m1sp01,desc,body),alt:desc};
  }
  const body=`<circle cx="105" cy="115" r="36" class="blue"/><rect x="195" y="78" width="74" height="74" rx="7" class="green"/><polygon points="365,72 320,151 410,151" class="yellow"/><rect x="466" y="86" width="116" height="58" rx="7" class="red"/><text x="105" y="176" class="small" text-anchor="middle">circle</text><text x="232" y="176" class="small" text-anchor="middle">square</text><text x="365" y="176" class="small" text-anchor="middle">triangle</text><text x="524" y="176" class="small" text-anchor="middle">rectangle</text>`;
  const desc="A circle, square, triangle and rectangle are shown so their sides and corners can be compared.";
  return {image:dataSvg(TITLES.ac9m1sp01,desc,body),alt:desc};
}

function sp02Visual(question) {
  const text=clean(`${question.question} ${question.imageAlt||""}`);
  const right=/right|east/i.test(text), left=/left|west/i.test(text), up=/up|north|forward/i.test(text), down=/down|south|back/i.test(text);
  const body=`<g transform="translate(82 46)">${Array.from({length:42},(_,i)=>`<rect x="${(i%7)*68}" y="${Math.floor(i/7)*27}" width="66" height="25" class="grid"/>`).join("")}<circle cx="34" cy="149" r="13" class="green"/><polygon points="442,8 451,27 472,29 456,44 461,65 442,54 423,65 428,44 412,29 433,27" class="yellow"/>${right?'<path d="M85 149 H250" class="arrow"/>':left?'<path d="M250 149 H85" class="arrow"/>':up?'<path d="M85 149 V45" class="arrow"/>':down?'<path d="M85 45 V149" class="arrow"/>':'<path d="M85 149 V68 H300" class="arrow"/>'}</g><text x="116" y="200" class="small">start</text><text x="530" y="78" class="small">target</text>`;
  const desc="A grid shows a start point, a target and a clear direction arrow.";
  return {image:dataSvg(TITLES.ac9m1sp02,desc,body),alt:desc};
}

function st01Visual(question) {
  const nums=numbersFrom(question.question);
  const counts=[nums[0]||4,nums[1]||3,nums[2]||2].map(v=>Math.max(1,Math.min(7,v)));
  const labels=["cat","dog","bird"];
  const body=labels.map((label,row)=>`<rect x="75" y="${58+row*47}" width="490" height="39" rx="7" class="panel"/><text x="105" y="${83+row*47}" class="small">${label}</text>${Array.from({length:counts[row]},(_,i)=>`<line x1="${205+i*29}" y1="${67+row*47}" x2="${205+i*29}" y2="${88+row*47}" class="tally"/>`).join("")}`).join("");
  const desc="A labelled tally table records each survey response once in the correct category.";
  return {image:dataSvg(TITLES.ac9m1st01,desc,body),alt:desc};
}
function st02Visual(question) {
  const nums=numbersFrom(question.question);
  const values=[nums[0]||5,nums[1]||3,nums[2]||4].map(v=>Math.max(1,Math.min(8,v)));
  const labels=["cats","dogs","birds"];
  const body=labels.map((label,row)=>`<text x="92" y="${78+row*50}" class="small">${label}</text>${Array.from({length:values[row]},(_,i)=>`<circle cx="${205+i*42}" cy="${72+row*50}" r="14" class="${["blue","green","yellow"][row]}"/>`).join("")}`).join("")+`<text x="320" y="198" class="tiny" text-anchor="middle">Key: each circle represents 1 response</text>`;
  const desc="A one-to-one picture display uses one circle for each response in a labelled category.";
  return {image:dataSvg(TITLES.ac9m1st02,desc,body),alt:desc};
}

function visualFor(code, question) {
  if (code === "ac9m1a01") return a01Visual(question);
  if (code === "ac9m1a02") return a02Visual(question);
  if (code === "ac9m1m01") return m01Visual(question);
  if (code === "ac9m1m02") return m02Visual(question);
  if (code === "ac9m1m03") return m03Visual(question);
  if (code === "ac9m1sp01") return sp01Visual(question);
  if (code === "ac9m1sp02") return sp02Visual(question);
  if (code === "ac9m1st01") return st01Visual(question);
  return st02Visual(question);
}
function needsVisual(question) {
  const text=clean(`${question.skill} ${question.question} ${question.imageAlt||""}`);
  return Boolean(question.image) || /show|shown|picture|display|pattern|sequence|line|balance|mass|capacity|container|measure|unit|gap|overlap|calendar|week|month|day|clock|shape|object|grid|route|direction|tally|survey|graph|data|frequency/i.test(text);
}
function removeFiller(text) {
  return clean(text)
    .replace(/^[A-Z][a-z]+ checks (?:another|a new) example\.\s*/i, "")
    .replace(/^A child checks (?:another|a new) example\.\s*/i, "");
}

const audit={ updatedQuestions:0, images:0, semanticChecks:0, codes:{} };
for (const code of CODES) {
  audit.codes[code]={practice:0,test:0,quiz:0};
  for (const bank of ["practice","test","quiz"]) {
    const rel=bank==="practice"?`quiz/year-1/math/${code}/practice/questions.js`:bank==="test"?`quiz/year-1/math/${code}/test/questions.js`:`quiz/year-1/math/${code}/questions.js`;
    const questions=load(rel).map(question=>{
      const next={...question,question:removeFiller(question.question)};
      if (needsVisual(next)) {
        const visual=visualFor(code,next);
        next.image=visual.image;
        next.imageAlt=visual.alt;
        delete next.visual;
        audit.images++;
        audit.codes[code][bank]++;
      }
      audit.updatedQuestions++;
      return next;
    });
    save(code,bank,questions);
  }
}

// Focused semantic gates for the areas where a generic shape would mislead a Year 1 learner.
for (const code of CODES) {
  for (const bank of ["practice","test","quiz"]) {
    const rel=bank==="practice"?`quiz/year-1/math/${code}/practice/questions.js`:bank==="test"?`quiz/year-1/math/${code}/test/questions.js`:`quiz/year-1/math/${code}/questions.js`;
    for (const question of load(rel)) {
      if (!question.image) continue;
      if (!/^data:image\/svg\+xml/.test(question.image) || !question.image.includes("width%3D%2213cm%22") || !question.image.includes("height%3D%225cm%22")) throw new Error(`${question.id}: invalid SVG size`);
      if (!question.imageAlt || question.imageAlt.length < 18) throw new Error(`${question.id}: missing meaningful imageAlt`);
      const text=clean(`${question.skill} ${question.question}`).toLowerCase();
      const alt=question.imageAlt.toLowerCase();
      if (code==="ac9m1m01" && /balance|mass|heavier|lighter/.test(text) && !/balance|mass|heavier/.test(alt)) throw new Error(`${question.id}: mass visual mismatch`);
      if (code==="ac9m1m02" && /gap/.test(text) && !/gap/.test(alt)) throw new Error(`${question.id}: gap visual mismatch`);
      if (code==="ac9m1m02" && /overlap/.test(text) && !/overlap/.test(alt)) throw new Error(`${question.id}: overlap visual mismatch`);
      if (code==="ac9m1a01" && /object|group/.test(text) && !/group/.test(alt)) throw new Error(`${question.id}: equal-group visual mismatch`);
      audit.semanticChecks++;
    }
  }
}

const reportPath="year1-maths-remaining-rebuild-report.json";
const report=JSON.parse(read(reportPath));
report.generatedAt=new Date().toISOString();
report.visualAudit={
  ...audit,
  standard:"Purpose-built SVGs match the object, comparison, pattern, measurement or data stimulus; minimum 1.3 cm rendered size and explicit 13 cm by 5 cm source size."
};
for (const code of CODES) {
  const key=code.toUpperCase();
  report.codes[key].visuals=Object.values(audit.codes[code]).reduce((sum,value)=>sum+value,0);
}
report.totals.visuals=Object.values(audit.codes).reduce((sum,banks)=>sum+Object.values(banks).reduce((inner,value)=>inner+value,0),0);
write(reportPath,JSON.stringify(report,null,2)+"\n");
console.log(JSON.stringify(audit,null,2));
